package org.ibm.plugin.example.tests.swtbot;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.swtbot.eclipse.finder.SWTWorkbenchBot;
import org.eclipse.swtbot.swt.finder.junit.SWTBotJunit4ClassRunner;
import org.eclipse.swtbot.swt.finder.widgets.SWTBotShell;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(SWTBotJunit4ClassRunner.class)
public class SampleTest {
	
	private static SWTWorkbenchBot	bot;
	private static IWorkspace workspace;
	 
	@BeforeClass
	public static void beforeClass() throws Exception {
		
		bot = new SWTWorkbenchBot();
		workspace = ResourcesPlugin.getWorkspace();
		bot.viewByTitle("Welcome").close();
		
	}

	@Test
	public void test() throws CoreException, InterruptedException {
		
		//prepare some test data
		String projectName = "Project_" + System.currentTimeMillis();
		String fileName = "File_" + System.currentTimeMillis() + ".mpe";
		IProject project = workspace.getRoot().getProject(projectName);
		project.create(null);
		project.open(null);
		
		//assert test data correctly created
		assertTrue(project.exists());
		assertFalse(project.getFile(fileName).exists());
		
		//open the wizard from menu
		bot.menu("File").menu("New").menu("Other...").click();
		
		SWTBotShell shell = bot.shell("New");
		shell.activate();
		
		Thread.sleep(1000); //wait for a second to see the result
		
		//Select our wizard
		bot.tree().expandNode("Sample Wizards").select("Multi-page Editor file");
		
		Thread.sleep(1000); //wait for a second to see the result
		
		//hit next
		bot.button("Next >").click();
		
		bot.textWithLabel("Container:").setText(project.getFullPath().toString());
		bot.textWithLabel("File name:").setText(fileName);
		
		Thread.sleep(1000); //wait for a second to see the result
		
		//hit fihish
		bot.button("Finish").click();
		
		Thread.sleep(4000); //wait for operation to complete
		
        //check the result
		assertTrue(project.getFile(fileName).exists());
		
	}

}
