package org.ibm.plugin.example.tests.ui;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.lang.reflect.Field;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.wizard.WizardDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.PlatformUI;
import org.junit.Before;
import org.junit.Test;

import com.ibm.plugin.example.wizards.SampleNewWizard;
import com.ibm.plugin.example.wizards.SampleNewWizardPage;

public class SamplePluginTest {
	private IWorkbench workbench;
	private IWorkspace workspace;
	
	@Before
	public void beforeTest(){

		workbench = PlatformUI.getWorkbench();
		workspace = ResourcesPlugin.getWorkspace();
		
	}
	
	
	/**
	 * Get private fields by reflection
	 * @param object
	 * @param name
	 * @return
	 */
	private static Object getField(Object object, String name) {
		try {
			Field field = null;
			Class clazz = object.getClass();
			NoSuchFieldException ex = null;
			while (field == null && clazz != null) {
				try {
					field = clazz.getDeclaredField(name);
				} catch (NoSuchFieldException e) {
					if (ex == null) {
						ex = e;
					}
					clazz = clazz.getSuperclass();
				}
			}
			if (field == null) {
				throw ex;
			}
			field.setAccessible(true);
			Object ret = field.get(object);
			return ret;
		} catch (IllegalArgumentException e) {
			fail(e.getMessage());
		} catch (IllegalAccessException e) {
			fail(e.getMessage());
		} catch (SecurityException e) {
			fail(e.getMessage());
		} catch (NoSuchFieldException e) {
			fail(e.getMessage());
		}
		return null;
	}

	@Test
	public void test() throws CoreException, InterruptedException {
		
		//prepare some test data		
		String projectName = "Project_" + System.currentTimeMillis();
		String fileName = "File_" + System.currentTimeMillis() + ".mpe";
		IProject project = workspace.getRoot().getProject(projectName);
		project.create(null);
		project.open(null);
		
		//assert test data correctly created
		assertTrue(project.exists());
		assertFalse(project.getFile(fileName).exists());
		
		//create and initialize our wizard
		SampleNewWizard wizard = new SampleNewWizard();
		wizard.init(workbench, null);
		
		//get shell for the wizard
		Shell shell = Display
				.getCurrent()
				.getActiveShell();
		
		//open a dialog with the wizard
        WizardDialog dialog = new WizardDialog(shell, wizard);
        dialog.create();
        dialog.getShell().setSize(
                Math.max(500, dialog.getShell().getSize().x),
                500);
        
        //IMPORTANT!!!
        //if dialog blocks on open than test won't go on until dialog is closed
        dialog.setBlockOnOpen(false);
        dialog.open();
        
        Thread.sleep(1000); //wait for a second to see the result
        
        //get the page from wizard
        assertEquals(1, wizard.getPages().length);
        SampleNewWizardPage page = (SampleNewWizardPage) wizard.getPages()[0];
        
        //get wizard fields though reflection
        Text containerText = (Text) getField(page, "containerText");
        containerText.setText(project.getFullPath().toString());
        Text fileText =  (Text) getField(page, "fileText");
        fileText.setText(fileName);
        
        Thread.sleep(1000); //wait for a second to see the result
        
        //simulate finish
        wizard.performFinish();
        
        //check if the file was created
        assertTrue(project.getFile(fileName).exists());
        
        Thread.sleep(1000); //wait for a second to see the result
		
	}

}
