package com.ibm.plugin.example.logic;

import com.ibm.plugin.example.model.SampleObject;

public class Sample {
	public boolean doSomething(){
		return true;
	}
	
	public SampleObject createSampleObject(String name, String longName){
		SampleObject obj = new SampleObject();
		obj.setId(System.currentTimeMillis());
		obj.setName(name);
		obj.setLongName(longName);
		return obj;
	}
}
