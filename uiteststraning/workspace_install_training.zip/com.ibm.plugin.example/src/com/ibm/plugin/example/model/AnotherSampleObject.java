package com.ibm.plugin.example.model;

public class AnotherSampleObject {

	public AnotherSampleObject(SampleObject sampleObject, String description,
			int index) {
		this.id = sampleObject.getId();
		this.name = sampleObject.getName();
		this.longName = sampleObject.getLongName();
		this.description = description;
		this.index = index;
	}

	private long id;

	private String name;

	private String longName;

	private String description;

	private int index;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLongName() {
		return longName;
	}

	public void setLongName(String longName) {
		this.longName = longName;
	}

	@Override
	public String toString() {
		return "AnotherSampleObject [id=" + id + ", name=" + name
				+ ", longName=" + longName + ", description=" + description
				+ ", index=" + index + "]";
	}
}
