package com.ibm.plugin.example.tests;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.ibm.plugin.example.logic.Sample;
import com.ibm.plugin.example.model.AnotherSampleObject;
import com.ibm.plugin.example.model.SampleObject;

public class SampleTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		new Sample().doSomething();
	}

	@Test
	public void testCreateSampleObject() {
		SampleObject obj = new Sample().createSampleObject("Szymon",
				"Szymon B.");
		Assert.assertEquals("1.0", "Szymon", obj.getName());
		Assert.assertEquals("2.0", "Szymon B.", obj.getLongName());
	}

	@Test
	public void testCreateAnotherSampleObject() {
		SampleObject obj = new Sample().createSampleObject("Szymon",
				"Szymon B.");
		AnotherSampleObject obj2 = new AnotherSampleObject(obj, "Desc", 0);

		Assert.assertEquals("1.0", "Szymon", obj2.getName());
		Assert.assertEquals("2.0", "Szymon B.", obj2.getLongName());
		Assert.assertEquals("3.0", "Desc", obj2.getDescription());
	}
}
